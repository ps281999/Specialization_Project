package com.example.react_api.Repo;

import com.example.react_api.Model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepo extends JpaRepository<Admin,Integer> {
//    public Admin findByEmailAndPass(String Email, String Pass);
}
