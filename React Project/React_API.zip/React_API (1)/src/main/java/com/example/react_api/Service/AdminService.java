package com.example.react_api.Service;

import com.example.react_api.Model.Admin;
import com.example.react_api.Model.User;
import com.example.react_api.Repo.AdminRepo;
import com.example.react_api.Repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AdminService {
        @Autowired
        AdminRepo adminRepo;
        public void store(Admin admin) {
            adminRepo.save(admin);
        }

//        public List<Admin> getUsers() {
//
//            List<Admin> list=adminRepo.findAll();
//
//            return list;
//        }

//       public Admin fetchadminbyemailandpass(String email,String pass) {
//           return AdminRepo.findByEmailAndPass(email,pass);
//       }


}
