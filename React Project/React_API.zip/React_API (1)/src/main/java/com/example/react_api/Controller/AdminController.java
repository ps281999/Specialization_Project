package com.example.react_api.Controller;

import com.example.react_api.Model.Admin;
import com.example.react_api.Model.User;
import com.example.react_api.Service.AdminService;
import com.example.react_api.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins="http://localhost:3000")
public class AdminController {
    @Autowired
    AdminService aservice;
    @Autowired
    UserService service;

    @PostMapping(value = "/saveadmin", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Admin> adminprint(@RequestBody Admin admin) {
        aservice.store(admin);
        return new ResponseEntity<Admin>(admin, HttpStatus.CREATED);
    }

//    @PostMapping("/adminlogin")
//    public Admin login(@RequestBody Admin admin) throws Exception {
//        String email = admin.getEmail();
//        String pass = admin.getPass();
//        Admin obj1 = null;
//        if (email != null && pass != null) {
//            System.out.print("admin exist");
//
//            obj1 = aservice.fetchadminbyemailandpass(email, pass);
//        }
//        if (obj1 == null) {
//            throw new Exception("admin does not exist");
//        }
//        return obj1;
//    }

//    @GetMapping(value = "/Users", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<List<User>> getUsers() {
//        List<User> list = service.getUsers();
//        return new ResponseEntity<List<User>>(list, HttpStatus.CREATED);
//    }
}