package com.example.bank_restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankRestApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
