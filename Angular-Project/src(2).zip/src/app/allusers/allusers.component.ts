import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { UserService } from '../user.service';
import { User } from '../user';
@Component({
  selector: 'app-allusers',
  templateUrl: './allusers.component.html',
  styleUrls: ['./allusers.component.css']
})
export class AllusersComponent {

  title='blog';
  list:any;
  constructor(private user:UserService){
    this.user.getData().subscribe(list=>{console.warn(list)
    this.list=list;
    })
}




}
