export class User{
    firstname:string='';
    lastname:string='';
    email:string='';
    mobile:number=0;
    pass:string='';
    account_type='';
}